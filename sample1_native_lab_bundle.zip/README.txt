Sample1 Native Lab Bundle (Benign, UPX-packable)
================================================

Why you saw errors
------------------
The previous sample you built was a .NET (managed) EXE. UPX does not support packing .NET assemblies,
so it reported ".NET files are not yet supported." To demonstrate UPX packing and .UPX sections,
you need a **native (unmanaged) PE**. This bundle provides that.

Files
-----
- sample1_native.c            C source with embedded "malware-like" strings (benign).
- build_native_msvc.bat       Build with Microsoft CL (open Developer Command Prompt).
- build_native_mingw.bat      Build with MinGW-w64 GCC.
- pack_with_upx_native.bat    Pack the native EXE with UPX -> sample1_native_packed.exe.

Build (MSVC)
------------
1) Open "x64 Native Tools Command Prompt for VS".
2) Run: build_native_msvc.bat
   -> Produces: sample1_native.exe

Build (MinGW-w64)
-----------------
1) Ensure gcc is in PATH.
2) Run: build_native_mingw.bat
   -> Produces: sample1_native.exe

Pack with UPX
-------------
1) Install UPX and ensure upx.exe is in PATH.
2) Run: pack_with_upx_native.bat
   -> Produces: sample1_native_packed.exe (shows .UPX sections and high entropy).

Lab Hints
---------
- Run 'strings sample1_native.exe' to find:
  * "Software\Microsoft\Windows\CurrentVersion\Run"
  * "SYSTEM\CurrentControlSet\Services"
  * "C:\Users\%USERNAME%\AppData\Roaming\svchost.exe"
  * "http://malicious-domain.com/login.php"
  * "kernel32.dll", "CreateProcessA"
- Inspect PE headers with PEview/PE-bear.
- Use DIE on sample1_native_packed.exe to observe .UPX sections & high entropy.

Safety
------
This binary is benign and performs no malicious action. Strings are present for analysis only.