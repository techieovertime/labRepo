// sample1_native.c - benign native PE for static analysis labs
#include <stdio.h>

const char* s1 = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
const char* s2 = "SYSTEM\\CurrentControlSet\\Services";
const char* s3 = "C:\\Users\\%USERNAME%\\AppData\\Roaming\\svchost.exe";
const char* s4 = "http://malicious-domain.com/login.php";
const char* s5 = "kernel32.dll";
const char* s6 = "CreateProcessA";

int main(int argc, char** argv) {
    printf("Hello from sample1_native.exe (benign training binary)\\n");
    return 0;
}