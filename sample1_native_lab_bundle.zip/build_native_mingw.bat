@echo off
where gcc >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
  echo [!] gcc not found. Install MinGW-w64 and ensure gcc is in PATH.
  exit /b 1
)
echo [+] Compiling sample1_native.c -> sample1_native.exe
gcc -s -O2 -Wall sample1_native.c -o sample1_native.exe
if %ERRORLEVEL% NEQ 0 (
  echo [!] Build failed.
  exit /b 1
)
echo [*] Build complete: sample1_native.exe