@echo off
where upx >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
  echo [!] upx.exe not found. Download from https://upx.github.io/ and add to PATH.
  exit /b 1
)
if not exist sample1_native.exe (
  echo [!] sample1_native.exe not found. Build it first.
  exit /b 1
)
echo [+] Packing sample1_native.exe -> sample1_native_packed.exe
upx --best --lzma -o sample1_native_packed.exe sample1_native.exe
if %ERRORLEVEL% NEQ 0 (
  echo [!] UPX packing failed (is the file a native PE?).
  exit /b 1
)
echo [*] Packed file created: sample1_native_packed.exe