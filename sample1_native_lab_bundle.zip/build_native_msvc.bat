@echo off
where cl >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
  echo [!] MSVC cl.exe not found. Open "x64 Native Tools Command Prompt for VS" and retry.
  exit /b 1
)
echo [+] Compiling sample1_native.c -> sample1_native.exe
cl /nologo /O1 /W3 /MT /GS- sample1_native.c /link /OUT:sample1_native.exe
if %ERRORLEVEL% NEQ 0 (
  echo [!] Build failed.
  exit /b 1
)
echo [*] Build complete: sample1_native.exe